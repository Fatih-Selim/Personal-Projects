package org.example.runner;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;

@Path("/")
public class CommentResource {

    @GET
    public String test() {
        return "new sub resource";
    }

    @GET
    @Path("/{commentId}")
    public String rest2(@PathParam("messageId") long messageId ,@PathParam("commentId") long commentId) {
        return "comment id returned " + commentId + "Message it returned " +messageId;
    }
}
